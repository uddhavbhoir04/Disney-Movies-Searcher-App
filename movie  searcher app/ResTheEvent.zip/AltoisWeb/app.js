burger = document.querySelector(".burger")
right = document.querySelector(".right")
header = document.querySelector(".header")

burger.addEventListener("click", ()=>{
    right.classList.toggle("v-class");
})
 
